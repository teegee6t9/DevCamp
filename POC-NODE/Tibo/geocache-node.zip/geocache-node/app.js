const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const port = 3000;
const DATA_FILE = path.join(__dirname, 'data', 'geocaches.json');

const cors = require('cors');
app.use(cors());


app.use(express.json());

function lireGeocaches() {
  const data = fs.readFileSync(DATA_FILE, 'utf8');
  return JSON.parse(data);
}

function sauvegarderGeocaches(geocaches) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(geocaches, null, 2));
}

app.get('/geocache/liste', (req, res) => {
  const geocaches = lireGeocaches();
  res.json(geocaches);
});

app.get(/^\/geocache\/(\d+)$/, (req, res) => {
  const id = parseInt(req.params[0]);
  const geocaches = lireGeocaches();
  const cache = geocaches.find(c => c.id === id);
  if (cache) {
    res.json(cache);
  } else {
    res.status(404).json({ message: "Geocache non trouvé." });
  }
});

app.get('/geocache/hasard', (req, res) => {
  const geocaches = lireGeocaches();
  const random = geocaches[Math.floor(Math.random() * geocaches.length)];
  res.json(random);
});

app.post('/geocache/ajouter', (req, res) => {
  const geocaches = lireGeocaches();
  const { nom, latitude, longitude } = req.body;

  if (!nom || !latitude || !longitude) {
    return res.status(400).json({ message: "Données manquantes." });
  }

  const nouvelle = {
    id: geocaches.length + 1,
    nom,
    latitude: parseFloat(latitude),
    longitude: parseFloat(longitude)
  };

  geocaches.push(nouvelle);
  sauvegarderGeocaches(geocaches);

  res.status(201).json(nouvelle);
});

app.listen(port, () => {
  console.log(`Serveur Geocaching (fichier) : http://localhost:${port}`);
});
