package org.apache.camel.camel_demo;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

import java.util.Map;

public class App {
    public static void main(String[] args) throws Exception {
        CamelContext context = new DefaultCamelContext();

        context.addRoutes(new RouteBuilder() {
            @Override
            public void configure() {
                from("timer:usersService?period=5000")
                    .setHeader("Accept", constant("application/json"))
                    .to("https://jsonplaceholder.typicode.com/users/1")
                    .unmarshal().json()
                    .process(exchange -> {
                        Map<String, Object> json = exchange.getIn().getBody(Map.class);
                        String nom = (String) json.get("name");
                        String email = (String) json.get("email");
                        String msg = String.format("[JSON] Utilisateur : %s — Email : %s", nom, email);
                        exchange.getIn().setBody(msg);
                    })
                    .to("stream:out");

                from("file:data/input?initialDelay=0&delay=3000&noop=true&include=personne.xml")
                    .log("XML lu depuis fichier : ${body}")
                    .log(">>> Route XML déclenchée")
                    .setHeader("nom", xpath("/personne/nom/text()"))
                    .setHeader("age", xpath("/personne/age/text()"))
                    .process(exchange -> {
                        String nom = exchange.getIn().getHeader("nom", String.class);
                        String age = exchange.getIn().getHeader("age", String.class);
                        String msg = String.format("[XML] Nom : %s — Âge : %s", nom, age);
                        exchange.getIn().setBody(msg);
                    })
                    .to("stream:out");
            }
        });

        context.start();
        Thread.sleep(20000);
        context.stop();
    }
}
