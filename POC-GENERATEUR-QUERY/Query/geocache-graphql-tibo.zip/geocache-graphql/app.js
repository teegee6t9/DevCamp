const express = require('express');
const { graphqlHTTP } = require('express-graphql');
const { buildSchema } = require('graphql');
const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, 'data', 'geocaches.json');

function lireGeocaches() {
  const raw = fs.readFileSync(DATA_FILE, 'utf8');
  return JSON.parse(raw);
}

const schema = buildSchema(`
  type Geocache {
    id: Int
    nom: String
    latitude: Float
    longitude: Float
  }

  type Query {
    geocache(id: Int!): Geocache
    geocaches: [Geocache]
    geocachesDansZone(minLat: Float!, maxLat: Float!): [Geocache]
    geocachesParNom(nomRegex: String!): [Geocache]
  }
`);

const root = {
  geocache: ({ id }) => lireGeocaches().find(g => g.id === id),
  geocaches: () => lireGeocaches(),
  geocachesDansZone: ({ minLat, maxLat }) =>
    lireGeocaches().filter(g => g.latitude >= minLat && g.latitude <= maxLat),
  geocachesParNom: ({ nomRegex }) => {
    const regex = new RegExp(nomRegex, "i");
    return lireGeocaches().filter(g => regex.test(g.nom));
  }
};

const app = express();
app.use('/graphql', graphqlHTTP({
  schema,
  rootValue: root,
  graphiql: true
}));

app.listen(4000, () => {
  console.log('GraphQL actif sur http://localhost:4000/graphql');
});
