 
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const port = 3000;
const DATA_FILE = path.join(__dirname, 'data', 'geocaches.json');

app.use(cors());
app.use(express.json());

function lireGeocaches() {
  const data = fs.readFileSync(DATA_FILE, 'utf8');
  return JSON.parse(data);
}

function sauvegarderGeocaches(geocaches) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(geocaches, null, 2));
}

app.get('/geocache/liste', (req, res) => {
  const geocaches = lireGeocaches();
  res.json(geocaches);
});

app.get(/^\/geocache\/(\d+)$/, (req, res) => {
  const id = parseInt(req.params[0]);
  const geocaches = lireGeocaches();
  const cache = geocaches.find(c => c.id === id);
  if (cache) {
    res.json(cache);
  } else {
    res.status(404).json({ message: "Geocache non trouvée." });
  }
});

app.post('/geocache/ajouter', (req, res) => {
  const { nom, proprietaire, latitude, longitude } = req.body;
  if (!nom || !proprietaire || !latitude || !longitude) {
    return res.status(400).json({ message: "Champs requis manquants." });
  }
  const geocaches = lireGeocaches();
  const nouvelle = {
    id: geocaches.length + 1,
    nom,
    proprietaire,
    latitude: parseFloat(latitude),
    longitude: parseFloat(longitude)
  };
  geocaches.push(nouvelle);
  sauvegarderGeocaches(geocaches);
  res.status(201).json(nouvelle);
});

app.put('/geocache/editer/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const geocaches = lireGeocaches();
  const index = geocaches.findIndex(c => c.id === id);
  if (index === -1) {
    return res.status(404).json({ message: "Geocache non trouvée." });
  }
  const { nom, proprietaire, latitude, longitude } = req.body;
  if (nom) geocaches[index].nom = nom;
  if (proprietaire) geocaches[index].proprietaire = proprietaire;
  if (latitude) geocaches[index].latitude = parseFloat(latitude);
  if (longitude) geocaches[index].longitude = parseFloat(longitude);
  sauvegarderGeocaches(geocaches);
  res.json(geocaches[index]);
});

app.delete('/geocache/effacer/:id', (req, res) => {
  const id = parseInt(req.params.id);
  let geocaches = lireGeocaches();
  const initialLength = geocaches.length;
  geocaches = geocaches.filter(c => c.id !== id);
  if (geocaches.length === initialLength) {
    return res.status(404).json({ message: "Geocache non trouvée." });
  }
  sauvegarderGeocaches(geocaches);
  res.json({ message: `Geocache ${id} effacée.` });
});

app.listen(port, () => {
  console.log(`API Geocache (fichier) disponible sur http://localhost:${port}`);
});
